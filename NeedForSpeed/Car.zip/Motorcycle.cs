﻿
namespace NeedForSpeed
{
   public  class Motorcycle : Vehicle
    {
        

        protected Motorcycle(int horsepower, double fuel) : base(horsepower, fuel)
        {

        }
        
    }
}
